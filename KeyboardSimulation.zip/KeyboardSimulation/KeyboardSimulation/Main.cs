﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;
using System.Windows.Forms;

namespace KeyboardSimulation
{
    public partial class Main : Form
    {
        [DllImport("user32.dll", EntryPoint = "keybd_event", SetLastError = true)]
        public static extern void keybd_event(Keys bVk, byte bScan, uint dwFlags, uint dwExtraInfo);
        private Boolean isStart = false;
        private Keys[] randomKey = { Keys.A, Keys.S, Keys.D, Keys.W,Keys.Space};
        private int[] randomIndex = { 0, 1, 2, 3, 4 };
        public Main()
        {
            InitializeComponent();
            this.btnCancel.Enabled = false;
        }

        private void btnStart_Click(object sender, EventArgs e)
        {
            this.btnStart.Enabled = false;
            this.btnCancel.Enabled = true;
            isStart = true;
            Thread th = new Thread(SendKeyBoard);
            th.IsBackground = true;
            th.Start();
        }



        private void SendKeyBoard() 
        {
            while (isStart) 
            {
                Random rd = new Random();
                int index = randomIndex[rd.Next(5)];
                Console.Out.WriteLine(index);
                Keys implementKey = randomKey[index];
                keybd_event(implementKey, 0, 0, 0);
                Thread.Sleep(100);
                keybd_event(implementKey, 0, 2, 0);
                int sleepTime = new Random().Next(5000, 20000);
                Console.Out.WriteLine(sleepTime);
                Thread.Sleep(sleepTime);
            }
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.btnStart.Enabled = true;
            this.btnCancel.Enabled = false;
            isStart = false;
        }
    }
}
